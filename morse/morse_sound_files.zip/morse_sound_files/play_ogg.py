#############################################
#											#
#   http://www.thelivingpearl.com           #
#											#
#   was wrriten by Captain DeadBones        #
#											#
#   cpt@thelivingpearl.com                  #
#											#
#############################################

import pygame
import time

pygame.init()
pygame.mixer.music.load('A_morse_code.ogg')
pygame.mixer.music.play()
time.sleep(1.5)
