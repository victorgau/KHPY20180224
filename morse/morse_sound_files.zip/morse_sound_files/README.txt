The files included with with this README file were downloaded from WikiMedia Commons. 

http://commons.wikimedia.org/wiki/Morse_code

